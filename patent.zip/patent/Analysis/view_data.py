from django.http import HttpResponse
from django.shortcuts import render
from selenium import webdriver
import time


# working though not efficient
def write_data():
    patent_list = [_ for _ in range(11840, 12840)]
    count = 1
    for patent_num in patent_list:
        print("Patent ", str(count), "\n\n")
        count = count + 1
        driver = webdriver.Firefox(executable_path="/home/hsingh/Downloads/geckodriver")
        time.sleep(2)
        driver.get('http://patft.uspto.gov/netahtml/PTO/search-bool.html')
        time.sleep(5)

        driver.find_element_by_xpath("//*[@id='fld2']").send_keys("P")
        time.sleep(2)
        term = driver.find_element_by_xpath("//input[@id='trm2']")
        term.send_keys(patent_num)

        button = driver.find_element_by_xpath("//input[@type='SUBMIT']")
        button.click()

        time.sleep(5)

        title = driver.find_element_by_xpath("//font[@size='+1']")
        print("Title : ", title.text)
        time.sleep(2)

        abstract = driver.find_element_by_xpath("//body[@bgcolor='#FFFFFF']/p")
        print("\nAbstract : ", abstract.text)
        time.sleep(2)

        driver.close()
    return HttpResponse('<h1> Data updated </h1>')