from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

import requests, csv, time
from bs4 import BeautifulSoup
from urllib.request import urlopen

# it is not working -- robots.txt interrupt
def write_csv(request):
    data_file = 'patent_output.csv'
    patent_numbers = [_ for _ in range(11840,12840)]

    header = ['Patent title', 'Abstract']

    def make_row(patent_number):
        url = 'https://patents.google.com/patent/US{}'.format(patent_number)

        r = requests.get(url, timeout=3)
        b = BeautifulSoup(r.text, 'html5lib')
        row = []

        # title
        _ = b.find('meta', attrs={'name': 'DC.title'}).attrs['content'].strip()
        row.append(_)

        # abstract
        _ = b.find('div', class_='abstract').text.strip()
        row.append(_)

        return row

    with open(data_file, 'w', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(header)
        for pn in patent_numbers:
            print(patent_numbers)
            try:
                writer.writerow(make_row(pn))
            except:
                writer.writerow([pn, 'error'])

            time.sleep(1)
    return HttpResponse('<h1> Data updated </h1>')

